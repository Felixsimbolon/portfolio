import { profile } from "@/lib/content";

export default function Nav() {
  return (
    <nav className="nav">
      <div className="shell nav-inner">
        <a href="#top" className="nav-logo">
          {profile.initials}
          <span className="dot">.</span>
        </a>
        <div className="nav-links">
          <a href="#work">work</a>
          <a href="#about" className="hide-sm">
            about
          </a>
          <a href="#skills" className="hide-sm">
            skills
          </a>
          <a href="#contact">contact</a>
        </div>
      </div>
    </nav>
  );
}
