import { hero, profile } from "@/lib/content";

export default function Hero() {
  return (
    <header id="top" className="shell hero">
      <p className="hero-eyebrow stagger">
        <span className="pulse" />
        {hero.eyebrow}
      </p>

      <h1 className="hero-title stagger">{hero.headline}</h1>

      <p className="hero-sub stagger">{hero.subline}</p>

      <div className="hero-cta stagger">
        <a href={hero.primaryCta.href} className="btn btn-primary">
          {hero.primaryCta.label}
          <span className="arrow">→</span>
        </a>
        <a href={hero.secondaryCta.href} className="btn btn-ghost">
          {hero.secondaryCta.label}
        </a>
      </div>

      <div className="hero-meta stagger">
        <span>
          Based in <b>{profile.location}</b>
        </span>
        <span>
          Status <b>{profile.availability}</b>
        </span>
        <span>
          Role <b>{profile.role}</b>
        </span>
      </div>
    </header>
  );
}
