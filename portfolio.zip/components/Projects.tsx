import { projects, type Project } from "@/lib/content";
import Reveal from "./Reveal";

function hasLink(url: string) {
  return url && !url.startsWith("[insert");
}

function ProjectRow({ p, index }: { p: Project; index: number }) {
  const hasImage = p.image && !p.image.startsWith("[insert");
  const reverse = index % 2 === 1;

  return (
    <Reveal>
      <article className={`project ${reverse ? "reverse" : ""}`}>
        <div className="project-info">
          <div className="project-head">
            <h3 className="project-title">{p.title}</h3>
            <span className="project-year">{p.year}</span>
          </div>

          <p className="project-tagline">{p.tagline}</p>

          <div className="project-detail">
            <span className="k">Problem</span>
            <span className="v muted">{p.problem}</span>
          </div>
          <div className="project-detail">
            <span className="k">Built</span>
            <span className="v">{p.contribution}</span>
          </div>
          <div className="project-detail">
            <span className="k">Impact</span>
            <span className="v">{p.impact}</span>
          </div>

          <div className="stack">
            {p.stack.map((s, i) => (
              <span className="chip" key={i}>
                {s}
              </span>
            ))}
          </div>

          {(hasLink(p.liveUrl) || hasLink(p.repoUrl)) && (
            <div className="project-links">
              {hasLink(p.liveUrl) && (
                <a href={p.liveUrl} target="_blank" rel="noopener noreferrer">
                  Live <span className="arrow">↗</span>
                </a>
              )}
              {hasLink(p.repoUrl) && (
                <a href={p.repoUrl} target="_blank" rel="noopener noreferrer">
                  Code <span className="arrow">↗</span>
                </a>
              )}
            </div>
          )}
        </div>

        <div className="project-visual">
          {hasImage ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={p.image as string} alt={p.title} />
          ) : (
            <div className="photo-placeholder">
              [ insert /project-{index + 1}.jpg in /public ]
            </div>
          )}
        </div>
      </article>
    </Reveal>
  );
}

export default function Projects() {
  return (
    <section id="work" className="section">
      <div className="shell">
        <Reveal>
          <p className="section-label">Selected Work</p>
        </Reveal>

        <div className="projects-list">
          {projects.map((p, i) => (
            <ProjectRow p={p} index={i} key={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
