import { about } from "@/lib/content";
import Reveal from "./Reveal";

export default function About() {
  const hasPhoto = about.photo && !about.photo.startsWith("[insert");

  return (
    <section id="about" className="section">
      <div className="shell">
        <Reveal>
          <p className="section-label">About</p>
        </Reveal>

        <div className="about-grid">
          <Reveal>
            <div className="about-photo">
              {hasPhoto ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={about.photo as string} alt="Portrait" />
              ) : (
                <div className="photo-placeholder">
                  [ insert /your-photo.jpg in /public ]
                </div>
              )}
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="about-body">
              {about.paragraphs.map((p, i) => (
                <p key={i}>{p}</p>
              ))}

              <div className="stats">
                {about.stats.map((s, i) => (
                  <div className="stat" key={i}>
                    <span className="num">{s.value}</span>
                    <span className="lbl">{s.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
